const { Client, Collection } = require("discord.js");
const client = new Client({intents: 131071});
const { TOKEN } = require('./config.json')

const { promisify } = require("util");
const Ascii = require("ascii-table");
const { glob } = require("glob");
const PG = promisify(glob);

client.commands = new Collection()

require("./Systems/GiveawaySystem")(client);

["Events", "Commands"].forEach(handler => {
    require(`./Handlers/${handler}`)(client, PG, Ascii);
});

client.login(TOKEN);
